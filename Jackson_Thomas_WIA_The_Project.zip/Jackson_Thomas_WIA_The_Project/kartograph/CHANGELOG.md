### 0.8.7
* fixed exposure of global classes

### 0.8.6
* exposing projections and View for projection showcase

### 0.8.2
* fixed centroid calculation for polygons with area = 0
* fixed order for polygons

### 0.8.1

* simplified API: loadMap() --> load()
* turned top level namespace into constructor function
* including versions in dist filesnames

### 0.7.1

* changed namespace to kartograph (lowercase)
* fixed glow filter
* added possibility to render layers in separate svg doc
* updated to work with jquery 1.10

### 0.6.7

* fixed HTML labels

### 0.6.6

* fixed satellite projection
